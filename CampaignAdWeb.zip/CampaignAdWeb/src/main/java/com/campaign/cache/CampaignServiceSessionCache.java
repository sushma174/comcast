
package com.campaign.cache;

import java.util.Collection;
import org.springframework.stereotype.Repository;
import com.campaign.vo.CampaignAd;
public interface CampaignServiceSessionCache {

	public CampaignAd getCampaignDataFromCacheByPartnerId(String key);
	
	public void putCampaignDataInCache(CampaignAd campaignAd);
	
	public void removeCampaignDataFromCache(String key);
	
	public void updateCampaignDataInCache(CampaignAd campaignAd);
	
	public void clearCache();
	
	public Collection getAllElements();
	
	public long getCacheSize();
	
}
