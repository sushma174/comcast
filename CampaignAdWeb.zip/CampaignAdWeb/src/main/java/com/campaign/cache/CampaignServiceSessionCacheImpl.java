
package com.campaign.cache;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;

import com.campaign.vo.CampaignAd;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

public class CampaignServiceSessionCacheImpl implements CampaignServiceSessionCache {
     
	private Cache cache;
	private int timeToLiveInSeconds=900;

	
	
	public CampaignAd getCampaignDataFromCacheByPartnerId(String key){
		
		Element element=cache.get(key);
		if(element !=null && element.getObjectValue()!=null)
			return (CampaignAd)element.getObjectValue();
		else 
			return null;
	}

	public void putCampaignDataInCache(CampaignAd  campaignAd){
		
		Element element=new Element(campaignAd.getPartnerId(), campaignAd);
		setTimeToLiveInSeconds(900);
		element.setTimeToLive(getTimeToLiveInSeconds());
		cache.put(element);
	}

	public void removeCampaignDataFromCache(String key){
		//MobileRequestLogger.debug(this.getClass().getName(), "Removing mobileMessage from cache for cell no " + key);
		cache.remove(key);
	}	

	public void clearCache(){
		//MobileRequestLogger.debug(this.getClass().getName(), "Clearing mobile session cache");
		cache.removeAll();
	}
	public void updateCampaignDataInCache(CampaignAd campaignAd){
	//public void updateMobileMessageInCache(MobileMessage mobileMessage) {
		String key = campaignAd.getPartnerId();

		Element element = cache.get(key);
		if (element!=null){
			removeCampaignDataFromCache(key);
		}
		long campaignCreationTime = System.currentTimeMillis();
		long totalTimeinMillis=campaignCreationTime+campaignAd.getDuration();
		
		campaignAd.setTotalTime(totalTimeinMillis);
		putCampaignDataInCache(campaignAd);
	}

	

	public long getCacheSize() {
		return cache.getSize();
	}

	public Collection<CampaignAd> getAllElements(){
		List<CampaignAd> campaignAds = null;
		if(this.cache != null){
			campaignAds = new ArrayList<CampaignAd>();
			List<?> s = cache.getKeys();
			Iterator<?> i = s.iterator();
			while(i.hasNext()){
				String key = (String) i.next();
				campaignAds.add(getCampaignDataFromCacheByPartnerId(key));
			}
		}
		return  campaignAds;
	}

	/**
	 * @return Returns the timeToLiveInSeconds.
	 */
	public int getTimeToLiveInSeconds() {
		return timeToLiveInSeconds;
	}
	/**
	 * @param timeToLiveInSeconds The timeToLiveInSeconds to set.
	 */
	public void setTimeToLiveInSeconds(int timeToLiveInSeconds) {
		this.timeToLiveInSeconds = timeToLiveInSeconds;
	}

	public Cache getCache() {
		return cache;
	}

	public void setCache(Cache cache) {
		this.cache = cache;
	}
	
}
