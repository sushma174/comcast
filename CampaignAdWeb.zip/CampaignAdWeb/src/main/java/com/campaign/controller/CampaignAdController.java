package com.campaign.controller;

import java.util.Collection;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


import com.campaign.cache.CampaignServiceSessionCache;
import com.campaign.cache.CampaignServiceSessionCacheImpl;
import com.campaign.vo.CampaignAd;
import com.campaign.vo.CampaignResponse;
import com.google.gson.Gson;

@RestController
@RequestMapping(value = "/ad/")
//@ImportResource("classpath*:CampaignAdService-servlet.xml")
public class CampaignAdController implements ApplicationContextAware {
	

/*Request JSON :
{
 "partnerId": "unique_string_representing_partner',
 "duration": "int_representing_campaign_duration_in_milliseconds_from_now"
 "adContent": "string_of_content_to_display_as_ad"
}*/
	

 	@Autowired
    private CampaignServiceSessionCache campaignServiceSessionCache;
	//URL to create campaign .http://<host>/ad/create
	@RequestMapping(value = "create", method = RequestMethod.POST,consumes = { MediaType.APPLICATION_JSON_VALUE})
	@ResponseBody
	public ResponseEntity<?> createCampaign(@RequestBody CampaignAd  campaignAd) throws Exception {		
		CampaignResponse response = new CampaignResponse();
		try {
			
			
			getCampaignServiceSessionCache().updateCampaignDataInCache(campaignAd);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			
			response.setResponse(e.getMessage());
			
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	//URL to return a campaign as JSON based on partner_id http://<host>/ad/<partner_id>
	@RequestMapping(value = "{partner_id}", method = RequestMethod.GET, produces = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseBody
	public ResponseEntity<?> getAdByPartner_Id(@PathVariable("partner_id") String partner_id) throws Exception {
		long methodStart = System.currentTimeMillis();
		Gson gson = new Gson();
		String response="";
		CampaignResponse error = new CampaignResponse();
		
		try {
		//	CampaignAd campaignAd=campaignServiceSessionCache.getCampaignDataFromCacheByPartnerId(partner_id);
			CampaignAd campaignAd=getCampaignServiceSessionCache().getCampaignDataFromCacheByPartnerId(partner_id);
			
			 if(methodStart>campaignAd.getTotalTime())
			 {
				
				 response="no active ad campaigns exist for the specified partner. ";
			 }
			 else
			 {
			response = gson.toJson(campaignAd);
			 }
			
		} catch (Exception e) {
			error.setResponse(e.getMessage());
			
			return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
			
		}
		
		
	    return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	//URL to return a list of all campaigns as JSON. http://<host>/ad/getAllCampaign

	@RequestMapping(value = "getAllCampaign", method = RequestMethod.GET, produces = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseBody
	public ResponseEntity<?> getAllAd() throws Exception {
		
		Gson gson = new Gson();
		String response="";
		CampaignResponse error = new CampaignResponse();
		
		try {
		//	CampaignAd campaignAd=campaignServiceSessionCache.getCampaignDataFromCacheByPartnerId(partner_id);
			Collection <CampaignAd> campaignAds=getCampaignServiceSessionCache().getAllElements();
			
			 
			response = gson.toJson(campaignAds);
			 
			
		} catch (Exception e) {
			error.setResponse(e.getMessage());
			//throw new Exception(e);
			return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
			
		}
		
		
	    return new ResponseEntity<>(response, HttpStatus.OK);
	}
	

	public CampaignServiceSessionCache getCampaignServiceSessionCache() {
		return campaignServiceSessionCache;
	}

	public void setCampaignServiceSessionCache(CampaignServiceSessionCache campaignServiceSessionCache) {
		this.campaignServiceSessionCache = campaignServiceSessionCache;
	}

	@Override
	public void setApplicationContext(ApplicationContext arg0) throws BeansException {
		// TODO Auto-generated method stub
		
	}
	

	

}
