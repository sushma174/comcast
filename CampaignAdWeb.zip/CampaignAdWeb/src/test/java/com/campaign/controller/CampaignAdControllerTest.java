package com.campaign.controller;


import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.servlet.mvc.annotation.AnnotationMethodHandlerAdapter;

import static org.springframework.test.web.server.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.server.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.server.setup.MockMvcBuilders.standaloneSetup;


@SuppressWarnings("deprecation")
@RunWith(SpringJUnit4ClassRunner.class)

//@ContextConfiguration(classes = {CampaignAdController.class})

@ContextConfiguration(locations = {"classpath*:/campaignAd-application-context.xml"})
public class CampaignAdControllerTest {

    private static final String HTTP_REQUEST_ACCEPT = "Accept:";
/*
    @Autowired
    protected ApplicationContext ctx;*/

    @Autowired
    protected CampaignAdController controller;

    private AnnotationMethodHandlerAdapter handlerAdapter;

    /**
     * @throws java.lang.Exception
     */
    @SuppressWarnings({"rawtypes"})
    @Before
    public void setUp() throws Exception {
        handlerAdapter = new AnnotationMethodHandlerAdapter();
        HttpMessageConverter[] messageConverters = {
                new MappingJackson2HttpMessageConverter(),
                new StringHttpMessageConverter()};
        handlerAdapter.setMessageConverters(messageConverters);

    }
  

	@Test
	public void testGetAdByPartner_Id() {
		try {
			
			standaloneSetup(controller)
					.setMessageConverters(handlerAdapter.getMessageConverters())
					.build()
					.perform(
							get("/ad/123").header(
									HTTP_REQUEST_ACCEPT,
									MediaType.APPLICATION_JSON_VALUE))
					.andExpect(status().isOk()).andReturn().getResponse();
			
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public CampaignAdController getController() {
		return controller;
	}

	public void setController(CampaignAdController controller) {
		this.controller = controller;
	}
	

}

