package com.example;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.XmlViewResolver;

import com.example.domain.Inventory;
import com.example.repository.InventoryRepository;

@SpringBootApplication
public class InventoryApplication extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(InventoryApplication.class);
	}

	public static void main(String[] args) throws Exception {
		SpringApplication.run(InventoryApplication.class, args);
	}
	
	
	@Bean
	public CommandLineRunner demo(InventoryRepository repository) {
		return (args) -> {
			// save a couple of Inventory
			repository.save(new Inventory("Shirt",20.00,35.00,3));
			repository.save(new Inventory("pant", 30.00,55.00,4));
			repository.save(new Inventory("tie", 15.00,27.00,5));
			
			// fetch all Inventory
			System.out.println("Inventory found with findAll():");
			
		for(Inventory inventory : repository.findAll()) {
				System.out.println(inventory.toString());
			}
		};
	}
	
	

}



		
			


		
