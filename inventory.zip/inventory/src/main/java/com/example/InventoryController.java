package com.example;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import org.springframework.web.util.UriComponentsBuilder;

import com.example.dao.InventoryDao;
import com.example.domain.Inventory;
import com.lowagie.text.Document;
import com.lowagie.text.Table;


@Controller
public class InventoryController {

	@Autowired
	InventoryDao inventoryService;
	
	@PostMapping(value = "/inventory/create")
	public ResponseEntity<Void> createInventory(
			String name, double costPrice, double sellingPrice, int quantity,UriComponentsBuilder ucBuilder){
		Inventory inventory=new Inventory(name,costPrice,sellingPrice,quantity);
		System.out.println("Creating Inventory with the name "
				+ inventory.getName());
		if (inventoryService.isInventoryExist(inventory)) {
			System.out.println("An inventory with name " + inventory.getName()
					+ " already exist");
			return new ResponseEntity<Void>(HttpStatus.CONFLICT);
		}

		inventoryService.saveInventory(inventory);

		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(ucBuilder.path("/inventory/name")
				.buildAndExpand(inventory.getName()).toUri());

		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	}

	@RequestMapping("/inventory/list")
	public ModelAndView listAllinventories(){
		List<Inventory> inventories = inventoryService.findAllInventories();
		
		return new ModelAndView("PdfView","inventories",inventories);
		

	}


	@PutMapping(value = "/inventory/buy/{name}/{quantity}")
	public ResponseEntity<Inventory> updateBuyInventory(
			@PathVariable("name") String name,
			@PathVariable("quantity") int quantity) {
		Inventory currentInventory = inventoryService.findByName(name);
		if (currentInventory == null) {
			System.out.println("Inventory with name " + name + " not found");
			return new ResponseEntity<Inventory>(HttpStatus.NOT_FOUND);
		}

		currentInventory.setQuantity(currentInventory.getQuantity() + quantity);
		inventoryService.updateInventory(currentInventory);
		return new ResponseEntity<Inventory>(currentInventory, HttpStatus.OK);

	}

	@PutMapping(value = "/inventory/sell/{name}/{quantity}")
	public ResponseEntity<Inventory> updateSellInventory(
			@PathVariable("name") String name,
			@PathVariable("quantity") int quantity) {
		Inventory currentInventory = inventoryService.findByName(name);
		if (currentInventory == null) {
			System.out.println("Inventory with name " + name + " not found");
			return new ResponseEntity<Inventory>(HttpStatus.NOT_FOUND);
		}
		currentInventory.setQuantity(currentInventory.getQuantity() - quantity);
		inventoryService.updateInventory(currentInventory);
		return new ResponseEntity<Inventory>(currentInventory, HttpStatus.OK);

	}

	@DeleteMapping(value = "/inventory/{name}")
	public ResponseEntity<Inventory> deleteInventory(
			@PathVariable("name") String name) {
		System.out.println("Fetching & Deleting Inventory with name " + name);

		Inventory inventory = inventoryService.findByName(name);
		if (inventory == null) {
			System.out.println("Unable to delete inventory with name " + name
					+ " not found");
			return new ResponseEntity<Inventory>(HttpStatus.NOT_FOUND);
		}

		inventoryService.deleteInventory(inventory);
		return new ResponseEntity<Inventory>(HttpStatus.NO_CONTENT);
	}

}
