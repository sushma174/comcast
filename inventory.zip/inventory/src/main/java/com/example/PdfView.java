package com.example;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.example.domain.Inventory;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;


public class PdfView extends AbstractPdfView {

	@Override
	protected void buildPdfDocument(Map<String, Object> model,
			Document document, PdfWriter writer, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		List<Inventory> invList= (List<Inventory>) model.get("inventories");

		PdfPTable table = new PdfPTable(4);
		table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		
		table.addCell("Item Name");
		table.addCell("Availability Qty");
		table.addCell("Bought At");
		table.addCell("Sold At");
		
		double totalCostPricePerItem=0.0;
		double totalSellingPricePerItem=0.0;
		for(Inventory inv:invList)
		{
        totalCostPricePerItem=inv.getQuantity()*inv.getCostPrice();
        totalSellingPricePerItem=inv.getQuantity()*inv.getSellingPrice();
		table.addCell(inv.getName());
		table.addCell(Integer.toString(inv.getQuantity()));
		table.addCell(Double.toString(inv.getCostPrice()));
		table.addCell(Double.toString(inv.getSellingPrice()));
		
		totalCostPricePerItem++;
		totalSellingPricePerItem++;
		}
		double profit=totalSellingPricePerItem-totalCostPricePerItem;
		
		table.addCell("Total Amount");
		table.addCell(Double.toString(totalCostPricePerItem));
		table.addCell("Profit");
		table.addCell(Double.toString(profit));
		
		document.add(table);

	}

}