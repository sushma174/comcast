package com.example.dao;

import java.util.List;

import com.example.domain.Inventory;

public interface InventoryDao {

	public void saveInventory(Inventory inventory);

	public List<Inventory> findAllInventories();

	public boolean isInventoryExist(Inventory inventory);

	public Inventory findByName(String name);

	public void deleteInventory(Inventory inventory);

	public Inventory updateInventory(Inventory inventory);

}
