package com.example.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.example.domain.Inventory;
import com.example.repository.InventoryRepository;

@Repository
public class InventoryDaoImpl implements  InventoryDao{
	
	@Autowired
	InventoryRepository repo;
	public void saveInventory(Inventory inventory){
		repo.save(inventory);
		}

	public List<Inventory> findAllInventories(){
		List<Inventory>inventories=(List<Inventory>) repo.findAll();
		return inventories;
		
	}

	public boolean isInventoryExist(Inventory inventory){
		long id=inventory.getId();
		boolean value=repo.exists(id);
		return value;
	}

	public Inventory findByName(String name){
		Inventory inventory=repo.findByName(name);
		return inventory;
		
	}

	public void deleteInventory(Inventory inventory){
		repo.delete(inventory);
		
		
	}

	public Inventory updateInventory(Inventory inventory){
		Inventory newInventory=repo.save(inventory);
		return newInventory;
		
	}


}
